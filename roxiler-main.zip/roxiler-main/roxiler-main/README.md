# Transaction Dashboard
MERN Stack Challenge by Roxiler
<br/>
View live app via this [Link](https://roxiler-transactions-dashboard.onrender.com/)
<br/>
<br/>
Frontend Technologies
- React
- Ant Design Components
- Chart.js
- Moment
- Axios

Backend Technologies
- Express
- Node
- Mongoose
- MongoDB
- Axios
